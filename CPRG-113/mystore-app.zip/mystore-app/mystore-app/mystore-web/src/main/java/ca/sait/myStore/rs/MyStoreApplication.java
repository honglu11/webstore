/**
 * 
 */
package ca.sait.myStore.rs;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

/**
 * @author honglu
 *
 */
@ApplicationPath("services")
public class MyStoreApplication extends Application {

}
