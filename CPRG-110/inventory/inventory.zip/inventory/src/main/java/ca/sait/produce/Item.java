/**
 * 
 */
package ca.sait.produce;

/**
 * @author Chris Elias
 *
 */
public interface Item {

    /**
     * 
     * @return
     */
    public Long getItemId();

    /**
     * 
     * @return
     */
    public String getName();
    
    
}
