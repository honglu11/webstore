/**
 *
 */
package ca.sait.cli;

/**
 *
 */
public class InvalidCommandException extends RuntimeException {

    /**
     * 
     */
    private static final long serialVersionUID = 1669814205839755606L;

}
