/**
 * 
 */
package ca.sait.mystore.web.mvc.model;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 */
public interface IModel {

    /**
     * 
     * @param request
     * @param response
     * @throws IOException
     * @throws ServletException
     */
    public String handle(HttpServletRequest request, HttpServletResponse response)
    throws IOException, ServletException;
    
    /**
     * 
     * @return
     */
    public String getNavigationName();

}
