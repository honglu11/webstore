package ca.sait.mystore.web;

/**
 * 
 */
public interface Constants {

    public static final String SESSION_LOCALE_KEY = "session.local.key";
    public static final String PARAM_LOCALE = "locale";
    
    public static final String ACTION = "action";
    public static final String PAGE_MESSAGE = "pageMessage";
}
