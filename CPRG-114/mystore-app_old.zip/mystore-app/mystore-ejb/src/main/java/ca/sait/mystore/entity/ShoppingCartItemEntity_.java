package ca.sait.mystore.entity;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2018-05-01T10:44:07.910-0600")
@StaticMetamodel(ShoppingCartItemEntity.class)
public class ShoppingCartItemEntity_ extends AbstractEntity_ {
	public static volatile SingularAttribute<ShoppingCartItemEntity, ShoppingCartEntity> cart;
	public static volatile SingularAttribute<ShoppingCartItemEntity, ProductEntity> product;
	public static volatile SingularAttribute<ShoppingCartItemEntity, Integer> quantity;
	public static volatile SingularAttribute<ShoppingCartItemEntity, Double> price;
}
