package ca.sait.utils;

public class WebPageUtil {

	public static final String FIRSTNAME = "Firstname";	
	public static final String LASTNAME = "Lastname";
	public static final String BIRTHDAY = "Birthday";
	public static final String SALARY = "Salary";

}
