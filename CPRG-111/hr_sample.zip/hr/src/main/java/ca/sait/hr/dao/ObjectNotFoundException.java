/**
 * 
 */
package ca.sait.hr.dao;

/**
 * @author celias
 *
 */
public class ObjectNotFoundException extends Exception {

	/**
	 * @param arg0
	 */
	public ObjectNotFoundException(String arg0) {
		super(arg0);
	}
}
