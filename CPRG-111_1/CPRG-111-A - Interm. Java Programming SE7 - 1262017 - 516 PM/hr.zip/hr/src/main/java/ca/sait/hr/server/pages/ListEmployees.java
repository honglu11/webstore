package ca.sait.hr.server.pages;

/**
 * URL = http://localhost:16000/list
 * 
 * this will display all the employees that have been
 * added to the database
 */
public class ListEmployees implements WebPage {

}
