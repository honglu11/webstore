/**
 * 
 */
package ca.sait.hr.server.pages;

/**
 * URL = http://localhost:16000/add?firstname=***&lastname=***&salary=***&dob=****
 *
 * This page accepts the employee information and addes
 * to the database
 */
public class AddEmployee implements WebPage {

}
