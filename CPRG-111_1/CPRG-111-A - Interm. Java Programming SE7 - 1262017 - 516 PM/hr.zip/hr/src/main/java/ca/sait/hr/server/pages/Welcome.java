/**
 * 
 */
package ca.sait.hr.server.pages;

/**
 * URL = http://localhost:16000/welcome
 * 
 * This page will display just a hello message and the form to 
 * enter a firstname, lastname, salary and date of birth
 *
 */
public class Welcome implements WebPage {

}
