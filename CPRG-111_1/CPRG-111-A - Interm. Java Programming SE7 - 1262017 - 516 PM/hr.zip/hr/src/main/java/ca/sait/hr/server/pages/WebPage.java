/**
 * 
 */
package ca.sait.hr.server.pages;

/**
 *
 */
public interface WebPage {

}
